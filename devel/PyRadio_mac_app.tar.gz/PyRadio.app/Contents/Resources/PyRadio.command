#!/bin/bash
set -euo pipefail

PYRADIO="$HOME/.local/bin/pyradio"

if [[ ! -x "$PYRADIO" ]]; then
    echo "PyRadio not found at: $PYRADIO"
    echo
    read -r -n 1 -p "Press any key to close..."
    echo
    exit 1
fi

printf '\033]0;PyRadio\007'
clear
exec "$PYRADIO"
